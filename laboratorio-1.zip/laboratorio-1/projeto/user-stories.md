
# Histórias de Usuário
> Gabriel Victor Couto Martins de Paula

| Quem                     | O Quê                                                  | Para Quê                           |
| ------------------------ | ------------------------------------------------------ | ---------------------------------- |
| Como Secretaria          | gostaria de gerar o currículo do semestre              | para organizar a disciplinas       |
| Como Secretaria          | gostaria de manter dados sobre professor               | para planejamento dos semestres    |
| Como Secretaria          | gostaria de manter dados da disciplina                 | para definição do currículo        |
| Como secretaria          | gostaria de manter dados sobre aluno                   | para manter contato                |
| Como Sistema de Cobrança | gostaria de realizar cobranças                         | para receber o pagamento           |
| Como Sistema de Cobrança | gostaria de ser notificado sobre novas matriculas      | para realizar cobranças            |
| Como Sistema de Cobrança | gostaria de ser notificado sobre matrículas canceladas | para não fazer cobranças indevidas |
| Como Aluno               | gostaria de me matricular                              | para cursar a disciplina           |
| Como Aluno               | gostaria de cancelar a matricula                       | para deixar de cursar a disciplina |
| Como Professor           | gostaria de visualizar alunos da disciplina            | para fazer chamadas                |