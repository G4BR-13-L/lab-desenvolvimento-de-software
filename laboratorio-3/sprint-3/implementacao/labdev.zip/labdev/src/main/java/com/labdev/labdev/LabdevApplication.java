package com.labdev.labdev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabdevApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabdevApplication.class, args);
	}

}
